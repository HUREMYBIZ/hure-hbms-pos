HURE HBMS POS — iPhone Edition

This is the final mobile/PWA design of the HURE hardware POS.

To use it like an iPhone app:
1. Put these files on an HTTPS web host.
2. Open index.html through that HTTPS address in Safari.
3. Tap Share > Add to Home Screen.
4. Open HURE POS from the iPhone Home Screen.

It works offline after the first successful load, and stores POS records locally.

For a true native App Store application, the same design can be packaged into a
SwiftUI/WKWebView iOS project and built/sign-installed with Xcode on a Mac.
